#ifndef LIBMATH_H
#define LIBMATH_H

namespace libmath {

    int fatorial( int n );

}

#endif
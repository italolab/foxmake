#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>

int main() {
    // Initialize GLFW
    if (!glfwInit()) {
        std::cerr << "Falha ao iniciar o GLFW\n";
        return -1;
    }

    // Cria no modo janela o contexto OpenGL
    GLFWwindow* window = glfwCreateWindow(800, 600, "OpenGL com MinGW e Foxmake", nullptr, nullptr);
    if (!window) {
        std::cerr << "Falha ao criar janela GLFW\n";
        glfwTerminate();
        return -1;
    }

    // Faz a janela como contexto corrente
    glfwMakeContextCurrent(window);

    // Inicializa o GLEW
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) {
        std::cerr << "Falha ao inicializar o GLEW\n";
        return -1;
    }

    // Loop principal
    while (!glfwWindowShouldClose(window)) {
        // Cor da janela
        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        // Operação de Swap para bufferes
        glfwSwapBuffers(window);

        // Poll para processar eventos
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}